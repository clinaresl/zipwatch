programa de programación dinámica
