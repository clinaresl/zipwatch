#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>


int main( int argc, char *argv[] ){
	/**We check correctness of arguments: over the correct number of arguments**/
	if( argc > 2){
		printf("Too many arguments\n");
		return -1;
	}
	/**We check correctness of arguments: under the correct number of arguments**/
	else if( argc < 2){
		printf("One argument is expected\n");
		return -1;
	}
	/**Variable to store file pointer for fscanf**/
	FILE *fp;
	/**Variable to store container name of most recent container checked.
	size set to 20 to store very big container names**/
  	char cont[20];
	/**We create an array of containers of max size 86 as, taking into account
	the smallest containers, the maximum fit of a ship of 3000tn is 86 containers**/
	char charge[86][20];
	/**Variables for the newest weight and perishability**/
	int  tons, perishability;
	/**Array to store the weight of a container in the position i of the ship**/
	int weights[86]={0};
	/**Array to store the perishability of a container in the position i of the ship**/
	int caducity[86]={0};
	/**Variable with the current total weight of the cargo**/
	int total_weight=0;
	/**Variable with the current total perishability value of the cargo**/
	int total_perish=0;
	/**Variable with the current total number of containers of the cargo**/
	int total_charge=0;

	/**We open the file as read mode and check for errors**/
  	if ((fp = fopen(argv[1],"r")) == NULL) {
    		perror("Error opening file");
    		exit(1);
  	}
  	/**Loop to get al containers from the input**/
	while(fscanf(fp, "%s %d %d", cont, &tons, &perishability)==3){
		/**If putting our container into the ship does not pass the capacity of the ship**/
		if(total_weight+tons<=3000 && total_charge < 86){
			/**We browse the array searching for empty spaces**/
			for(int i=0;i<86;i++){
				/**We set the position of the array to the new values
				will only work for the first iteration of i, then we will continue
				executing while ordering a little the array**/
				if(caducity[i]==0){
					/**String set as container name**/
					strcpy(charge[i],cont);
					/**Weight set as container weight**/
					weights[i]=tons;
					/**Caducity set as products perishability**/
					caducity[i]=perishability;
					/**We add the weight to the total charge**/
					total_weight+=tons;
					/**We add the perishability to the total value**/
					total_perish+=perishability;
					/**Total number of containers being charged increases by 1**/
					total_charge++;
					/**i is set to the end of loop to get a new container**/
					i=86;
				}/**End of if**/
				else if(caducity[i]!=0 && caducity[i+1]==0){
					if(caducity[i]>=perishability){
						/**Old container name is moved one position back**/
						strcpy(charge[i+1],charge[i]);
						/**Old weight is moved one position back**/
						weights[i+1]=weights[i];
						/**Old perishability is moved one position back**/
						caducity[i+1]=caducity[i];
						/**String set as new container name**/
						strcpy(charge[i],cont);
						/**Weight set as new container weight**/
						weights[i]=tons;
						/**Caducity set as new products perishability**/
						caducity[i]=perishability;
						/**We add the weight to the total charge**/
						total_weight+=tons;
						/**We add the perishability to the total value**/
						total_perish+=perishability;
						/**Total number of containers being charged increases by 1**/
						total_charge++;
						/**i is set to the end of loop to get a new container**/
						i=86;
					}/**End of if**/
					else{
						/**New container name set at next position**/
						strcpy(charge[i+1],cont);
						/**New container weight set at next position**/
						weights[i+1]=tons;
						/**New container perishability set at next position**/
						caducity[i+1]=perishability;
						/**We add the weight to the total charge**/
						total_weight+=tons;
						/**We add the perishability to the total value**/
						total_perish+=perishability;
						/**Total number of containers being charged increases by 1**/
						total_charge++;
						/**i is set to the end of loop to get a new container**/
						i=86;
					}/**End of else**/
				}/**End of else if**/
						
			}/**End of for**/
		}/**End of if**/
		/**Checks if ship is full when there is still containers to check**/
		if(total_weight+tons>3000 || total_charge==86){
			/**traverses the cargo from both extremes to find the smallest caducities.
			Priority goes to start of the array as our insertion gives priority to 
			insert small perishabilities first, but can insert a small one at the end or middle
			in some situations, so checking all is necessary**/
			for(int i=0;i<(total_charge/2+1);i++){
				/**We check the start of the array**/
				if(caducity[i]<perishability && (total_weight+tons-weights[i]<=3000)){
					/**New container name substitues old**/
					strcpy(charge[i],cont);
					/**Take out the perishability of the old container and add the new**/
					total_perish-=caducity[i];
					total_perish+=perishability;
					/**Substitue the perishability**/
					caducity[i]=perishability;
					/**Take out old weight and insert new on total and the array**/
					total_weight-=weights[i];
					total_weight+=tons;
					weights[i]=tons;
					/**Set the i out of the array to get next container**/
					i=total_charge;
				}/**End of if**/
				else if(caducity[total_charge-1-i]<perishability && (total_weight+tons-weights[total_charge-1-i]<=3000)){
					/**New container name substitues old**/
					strcpy(charge[total_charge-1-i],cont);
					/**Take out the perishability of the old container and add the new**/
					total_perish-=caducity[total_charge-1-i];
					total_perish+=perishability;
					/**Substitue the perishability**/
					caducity[total_charge-1-i]=perishability;
					/**Take out old weight and insert new on total and the array**/
					total_weight-=weights[total_charge-1-i];
					total_weight+=tons;
					weights[total_charge-1-i]=tons;
					/**Set the i out of the array to get next container**/
					i=total_charge;
				}/**End of else if**/
			}/**End of for**/
		}/**End of if**/
	}/**End of while**/

	
	/**We print the results**/
	printf("total value: %d\n",total_perish);
	/**We need to browse the array of charge to print all the containers in the ship**/
	printf("containers: ");
	for(int i=0; i<total_charge; i++){
		printf("%s ",charge[i]);
	}
	printf("\n");
	/**We end the execution sucesfully**/
	return(0);
}
