implementation in a professional programming language
